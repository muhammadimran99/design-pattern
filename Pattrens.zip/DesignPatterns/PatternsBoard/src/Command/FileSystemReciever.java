
package Command;


public interface FileSystemReciever {
    void openFile();
	void closeFile();
	void writeFile();
}
