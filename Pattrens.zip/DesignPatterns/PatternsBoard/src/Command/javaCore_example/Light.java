package Command.javaCore_example;
//Receiver

public class Light {

	private boolean isOn;

	public void switchOn() {
		isOn = true;
	}

	public void switchOff() {
		isOn = false;
	}

}
